git config --global user.email "skyline27042012@gmail.com"
git config --global user.name "tuan"
git init
git add --all
git commit -m "first commit"
git remote add origin https://github.com/skyline27042012/elasticsearch-spark-hadoop.git
git push -u origin master